# TabControl + Aiven MySQL + monitoramento da bateria Android

Esta versão foi preparada para migrar o sistema inteiro do SQLite local para o MySQL gerenciado no Aiven.

## Comece por aqui

1. Leia `Servidor_TabControl/README_MIGRACAO_AIVEN.md` e faça backup do banco `tabcontrol.db`.
2. Instale os pacotes Python com `pip install -r Servidor_TabControl/requirements.txt` (recomendado usar ambiente virtual).
3. Copie `Servidor_TabControl/.env.example` para `Servidor_TabControl/.env` e preencha as configurações da sua instância Aiven e o caminho do certificado CA. Não compartilhe nem publique `.env`.
4. Execute `python migrar_sqlite_para_mysql.py` a partir da pasta `Servidor_TabControl` e digite `MIGRAR` somente após conferir as contagens.
5. Inicie `Servidor.py` na mesma pasta.
6. Abra o app Android e configure o endereço do servidor: `http://10.0.2.2:8000` para o emulador no mesmo computador.

O Android se comunica apenas com a API Python. As credenciais do banco ficam no servidor e não são incluídas no app.


## Migração para MySQL na nuvem

Para migrar o banco SQLite local para o Aiven MySQL, siga o guia completo `LEIA-ME-MIGRACAO-MYSQL.md`. Configure as credenciais apenas em `Servidor_TabControl/.env`; não as coloque no código nem no app Android.
