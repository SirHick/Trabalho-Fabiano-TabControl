# App Android - TabControl Bateria

O app lê a bateria deste aparelho e envia automaticamente a porcentagem ao TabControl.

## Abrir
1. Abra esta pasta no Android Studio (a pasta que contém `settings.gradle.kts`).
2. Aguarde a sincronização do Gradle; é necessário baixar a dependência do WorkManager na primeira execução.
3. Execute no emulador ou aparelho Android.

## Primeira configuração
1. Deixe o servidor Python do TabControl em execução.
2. Use `http://10.0.2.2:8000` no emulador.
3. Clique em **Buscar cadastros no banco**.
4. Selecione o registro do inventário que corresponde a este aparelho e clique em **Ativar monitoramento automático**.

A seleção é necessária uma única vez para identificar a qual cadastro a leitura pertence. O valor de bateria não é digitado; é lido pelo próprio Android. Para outro tablet físico, instale o app e faça o vínculo dele ao seu código cadastrado.

## Segundo plano

O app agenda uma leitura imediata e um trabalho periódico do WorkManager a cada 15 minutos, condicionado à conectividade. O Android pode adiar execuções. O painel web atualiza a bateria periodicamente enquanto a página está aberta.

No emulador o endereço do computador é `10.0.2.2`. Em dispositivo físico, use o IP local do computador/servidor e prepare o servidor para acesso à rede local. O servidor de teste não possui autenticação e não deve ser exposto diretamente à internet.
