"""
TabControl - controle e gerenciamento dos tablets do armario (Centro WEG)
Equipe Brokers - Implementacao de Negocios Inovadores

Roda no PyCharm com MySQL gerenciado pelo Aiven. Configure as variaveis no arquivo .env.

A leitura da tag RFID e simulada: voce digita o codigo da tag no console.
Quando o ESP32 + leitor RFID estiverem prontos, e so trocar o input()
da funcao ler_tag() pela leitura real (serial, MQTT, HTTP, etc).
"""

import os
import smtplib
import ssl

import pymysql
from pymysql.cursors import DictCursor
from pymysql.err import IntegrityError
from dotenv import load_dotenv
from contextlib import contextmanager
from datetime import datetime, timedelta
from email.message import EmailMessage

# ------------------------------------------------------------------
# Configuracoes
# ------------------------------------------------------------------
PASTA = os.path.dirname(os.path.abspath(__file__))
DB_ARQUIVO = os.path.join(PASTA, "tabcontrol.db")
load_dotenv(os.path.join(PASTA, ".env"))


class Linha(dict):
    """Linha compatível com o código antigo: aceita chave ou índice numérico."""
    def __getitem__(self, chave):
        if isinstance(chave, int):
            return tuple(self.values())[chave]
        return super().__getitem__(chave)


class CursorCompativel:
    def __init__(self, cursor):
        self.cursor = cursor

    def execute(self, sql, parametros=None):
        # O projeto foi escrito com placeholders SQLite (?). Converte para PyMySQL (%s).
        sql_mysql = sql.replace("?", "%s")
        self.cursor.execute(sql_mysql, parametros or ())
        if self.cursor.description is None:
            self.cursor.close()
        return self

    def fetchone(self):
        try:
            linha = self.cursor.fetchone()
            return Linha(linha) if linha is not None else None
        finally:
            self.cursor.close()

    def fetchall(self):
        try:
            return [Linha(linha) for linha in self.cursor.fetchall()]
        finally:
            self.cursor.close()

    def close(self):
        self.cursor.close()


class ConexaoCompativel:
    def __init__(self, conexao):
        self.conexao = conexao

    def execute(self, sql, parametros=None):
        cursor = CursorCompativel(self.conexao.cursor(DictCursor))
        return cursor.execute(sql, parametros)

    def commit(self):
        self.conexao.commit()

    def rollback(self):
        self.conexao.rollback()

    def close(self):
        self.conexao.close()

BATERIA_MINIMA = 50          # abaixo disso (49% ou menos) bloqueia a retirada; 50% ainda libera (%)
DIAS_MAX_ANTECEDENCIA = 7    # evita "reserva muito antecipada"
TOLERANCIA_RETIRADA_MIN = 5 # pode retirar ate 5 min antes do horario reservado

# Email: se SMTP_HOST ficar None, os emails so aparecem no console (simulado)
SMTP_HOST = None             # ex: "smtp.gmail.com"
SMTP_PORTA = 587
SMTP_USUARIO = ""
SMTP_SENHA = ""
EMAIL_ADMIN = "administracao@exemplo.com"

FMT_BANCO = "%Y-%m-%d %H:%M"
FMT_TELA = "%d/%m/%Y %H:%M"


# ------------------------------------------------------------------
# Banco de dados MySQL (Aiven)
# ------------------------------------------------------------------
load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))

MYSQL_HOST = os.getenv("MYSQL_HOST", "")
MYSQL_PORT = int(os.getenv("MYSQL_PORT", "3306"))
MYSQL_USER = os.getenv("MYSQL_USER", "")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "defaultdb")
MYSQL_SSL_CA = os.getenv("MYSQL_SSL_CA", "")


class Linha(dict):
    """Linha que aceita acesso por nome (linha['id']) e por indice (linha[0])."""
    def __getitem__(self, chave):
        if isinstance(chave, int):
            return list(self.values())[chave]
        return super().__getitem__(chave)


class CursorAdaptado:
    def __init__(self, cursor):
        self._cursor = cursor

    def fetchone(self):
        linha = self._cursor.fetchone()
        return Linha(linha) if linha is not None else None

    def fetchall(self):
        return [Linha(linha) for linha in self._cursor.fetchall()]


class ConexaoAdaptada:
    """Mantem o estilo con.execute(..., parametros) usado pelo codigo original."""
    def __init__(self, conexao):
        self._conexao = conexao

    def execute(self, sql, parametros=None):
        # O codigo do TabControl usa placeholders SQLite '?'; PyMySQL usa '%s'.
        sql_mysql = sql.replace("?", "%s")
        cursor = self._conexao.cursor(DictCursor)
        cursor.execute(sql_mysql, parametros or ())
        return CursorAdaptado(cursor)

    def commit(self):
        self._conexao.commit()

    def rollback(self):
        self._conexao.rollback()

    def close(self):
        self._conexao.close()


def _abrir_mysql():
    faltando = [nome for nome, valor in {
        "MYSQL_HOST": MYSQL_HOST,
        "MYSQL_USER": MYSQL_USER,
        "MYSQL_PASSWORD": MYSQL_PASSWORD,
        "MYSQL_DATABASE": MYSQL_DATABASE,
    }.items() if not valor]
    if faltando:
        raise RuntimeError("Configure no arquivo .env as variaveis: " + ", ".join(faltando))
    if not MYSQL_SSL_CA or not os.path.isfile(MYSQL_SSL_CA):
        raise RuntimeError(
            "Certificado CA do Aiven nao encontrado. Defina MYSQL_SSL_CA no .env "
            "com o caminho completo do arquivo ca.pem baixado no painel Aiven."
        )
    contexto_ssl = ssl.create_default_context(cafile=MYSQL_SSL_CA)
    conexao = pymysql.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        charset="utf8mb4",
        cursorclass=DictCursor,
        connect_timeout=15,
        read_timeout=30,
        write_timeout=30,
        ssl=contexto_ssl,
        autocommit=False,
    )
    return ConexaoAdaptada(conexao)


@contextmanager
def conectar():
    """Abre conexão TLS com o MySQL do Aiven e mantém o padrão de uso do projeto."""
    host = os.getenv("MYSQL_HOST", "").strip()
    porta = int(os.getenv("MYSQL_PORT", "3306"))
    usuario = os.getenv("MYSQL_USER", "").strip()
    senha = os.getenv("MYSQL_PASSWORD", "")
    banco = os.getenv("MYSQL_DATABASE", "defaultdb").strip()
    certificado = os.getenv("MYSQL_SSL_CA", "").strip()

    faltando = [nome for nome, valor in {
        "MYSQL_HOST": host, "MYSQL_USER": usuario, "MYSQL_PASSWORD": senha,
        "MYSQL_DATABASE": banco, "MYSQL_SSL_CA": certificado
    }.items() if not valor]
    if faltando:
        raise RuntimeError("Configure as variáveis no arquivo .env: " + ", ".join(faltando))
    if not os.path.isfile(certificado):
        raise RuntimeError(f"Certificado TLS não encontrado: {certificado}. Baixe o CA da Aiven e ajuste MYSQL_SSL_CA.")

    conexao = pymysql.connect(
        host=host,
        port=porta,
        user=usuario,
        password=senha,
        database=banco,
        charset="utf8mb4",
        cursorclass=DictCursor,
        autocommit=False,
        connect_timeout=10,
        read_timeout=20,
        write_timeout=20,
        ssl={"ca": certificado},
        ssl_verify_cert=True,
        ssl_verify_identity=True,
    )
    con = ConexaoCompativel(conexao)
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def criar_tabelas():
    """Cria as tabelas no MySQL caso ainda não existam."""
    comandos = [
        """CREATE TABLE IF NOT EXISTS professores (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(255) NOT NULL,
            email VARCHAR(320) NOT NULL UNIQUE,
            tag_rfid VARCHAR(191) NOT NULL UNIQUE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""",
        """CREATE TABLE IF NOT EXISTS tablets (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            codigo VARCHAR(191) NOT NULL UNIQUE,
            tag_rfid VARCHAR(191) NOT NULL UNIQUE,
            bateria INT NOT NULL DEFAULT 100,
            hardware VARCHAR(20) NOT NULL DEFAULT 'ok',
            status VARCHAR(30) NOT NULL DEFAULT 'disponivel'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""",
        """CREATE TABLE IF NOT EXISTS reservas (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            professor_id BIGINT NOT NULL,
            tablet_id BIGINT NOT NULL,
            inicio VARCHAR(19) NOT NULL,
            fim VARCHAR(19) NOT NULL,
            status VARCHAR(30) NOT NULL DEFAULT 'ativa',
            CONSTRAINT fk_reservas_professor FOREIGN KEY (professor_id) REFERENCES professores(id),
            CONSTRAINT fk_reservas_tablet FOREIGN KEY (tablet_id) REFERENCES tablets(id),
            INDEX idx_reservas_tablet_horario (tablet_id, status, inicio, fim)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""",
        """CREATE TABLE IF NOT EXISTS emprestimos (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            professor_id BIGINT NOT NULL,
            tablet_id BIGINT NOT NULL,
            retirada VARCHAR(19) NOT NULL,
            devolucao VARCHAR(19) NULL,
            bateria_retirada INT NULL,
            bateria_devolucao INT NULL,
            CONSTRAINT fk_emprestimos_professor FOREIGN KEY (professor_id) REFERENCES professores(id),
            CONSTRAINT fk_emprestimos_tablet FOREIGN KEY (tablet_id) REFERENCES tablets(id),
            INDEX idx_emprestimos_abertos (tablet_id, devolucao)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""",
        """CREATE TABLE IF NOT EXISTS observacoes (
            id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
            tablet_id BIGINT NOT NULL,
            professor_id BIGINT NULL,
            data VARCHAR(19) NOT NULL,
            texto TEXT NOT NULL,
            tipo VARCHAR(30) NOT NULL DEFAULT 'observacao',
            resolvido TINYINT NOT NULL DEFAULT 0,
            CONSTRAINT fk_observacoes_tablet FOREIGN KEY (tablet_id) REFERENCES tablets(id),
            CONSTRAINT fk_observacoes_professor FOREIGN KEY (professor_id) REFERENCES professores(id),
            INDEX idx_observacoes_data (data)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci""",
    ]
    with conectar() as con:
        for comando in comandos:
            con.execute(comando)


# ------------------------------------------------------------------
# Utilidades
# ------------------------------------------------------------------
def agora():
    return datetime.now().strftime(FMT_BANCO)


def para_tela(texto_banco):
    if not texto_banco:
        return "-"
    return datetime.strptime(texto_banco, FMT_BANCO).strftime(FMT_TELA)


def ler_data(texto):
    """Converte 'dd/mm/aaaa hh:mm' em datetime. Retorna None se estiver errado."""
    try:
        return datetime.strptime(texto.strip(), FMT_TELA)
    except ValueError:
        return None


def ler_tag(msg):
    # Aqui entra a leitura real do RFID depois. Por enquanto, digita.
    return input(msg).strip()


def enviar_email(destino, assunto, corpo):
    if not SMTP_HOST:
        print(f"\n[EMAIL SIMULADO] para: {destino}\n  assunto: {assunto}\n  {corpo}\n")
        return
    try:
        msg = EmailMessage()
        msg["From"] = SMTP_USUARIO
        msg["To"] = destino
        msg["Subject"] = assunto
        msg.set_content(corpo)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORTA) as srv:
            srv.starttls()
            srv.login(SMTP_USUARIO, SMTP_SENHA)
            srv.send_message(msg)
    except Exception as e:
        print(f"Nao consegui enviar o email ({e})")


# ------------------------------------------------------------------
# Cadastros
# ------------------------------------------------------------------
def cadastrar_professor(nome, email, tag):
    try:
        with conectar() as con:
            con.execute("INSERT INTO professores (nome, email, tag_rfid) VALUES (?, ?, ?)",
                        (nome, email, tag))
        return True, f"Professor {nome} cadastrado."
    except IntegrityError:
        return False, "Ja existe professor com esse email ou essa tag."


def cadastrar_tablet(codigo, tag):
    try:
        with conectar() as con:
            con.execute("INSERT INTO tablets (codigo, tag_rfid) VALUES (?, ?)", (codigo, tag))
        return True, f"Tablet {codigo} cadastrado."
    except IntegrityError:
        return False, "Ja existe tablet com esse codigo ou essa tag."


def atualizar_status_tablet(codigo, bateria, hardware):
    """Simula o que o ESP32 vai mandar (bateria e estado do hardware)."""
    if not 0 <= bateria <= 100:
        return False, "Bateria tem que estar entre 0 e 100."
    if hardware not in ("ok", "defeito"):
        return False, "Hardware tem que ser 'ok' ou 'defeito'."
    with conectar() as con:
        tablet = con.execute("SELECT * FROM tablets WHERE codigo = ?", (codigo,)).fetchone()
        if not tablet:
            return False, "Tablet nao encontrado."
        novo_status = tablet["status"]
        if hardware == "defeito" and tablet["status"] == "disponivel":
            novo_status = "manutencao"
        elif hardware == "ok" and tablet["status"] == "manutencao":
            novo_status = "disponivel"
        con.execute("UPDATE tablets SET bateria = ?, hardware = ?, status = ? WHERE id = ?",
                    (bateria, hardware, novo_status, tablet["id"]))
        if hardware == "ok" and tablet["hardware"] != "ok":
            # tablet consertado: os defeitos em aberto passam a "resolvidos"
            con.execute("""UPDATE observacoes SET resolvido = 1
                           WHERE tablet_id = ? AND tipo = 'defeito' AND resolvido = 0""", (tablet["id"],))
    return True, f"{codigo}: bateria {bateria}%, hardware {hardware}, status {novo_status}."


# ------------------------------------------------------------------
# Exclusao de cadastros
# ------------------------------------------------------------------
def _plural(n, singular, plural):
    return f"{n} {singular if n == 1 else plural}"


def excluir_professor(prof_id, forcar=False):
    """Retorna (ok, msg) ou (False, msg, True) quando precisa de confirmacao."""
    with conectar() as con:
        prof = con.execute("SELECT * FROM professores WHERE id = ?", (prof_id,)).fetchone()
        if not prof:
            return False, "Professor nao encontrado."
        if con.execute("SELECT 1 FROM emprestimos WHERE professor_id = ? AND devolucao IS NULL",
                       (prof_id,)).fetchone():
            return False, (f"{prof['nome']} esta com um tablet emprestado. "
                           "Registre a devolucao antes de excluir.")

        n_emp = con.execute("SELECT COUNT(*) FROM emprestimos WHERE professor_id = ?", (prof_id,)).fetchone()[0]
        n_res = con.execute("SELECT COUNT(*) FROM reservas WHERE professor_id = ?", (prof_id,)).fetchone()[0]
        n_obs = con.execute("SELECT COUNT(*) FROM observacoes WHERE professor_id = ?", (prof_id,)).fetchone()[0]

        if (n_emp or n_res) and not forcar:
            return False, (f"{prof['nome']} tem {_plural(n_emp, 'emprestimo', 'emprestimos')} no historico e "
                           f"{_plural(n_res, 'reserva', 'reservas')}. Excluir o professor tambem apaga esses registros."), True

        con.execute("DELETE FROM emprestimos WHERE professor_id = ?", (prof_id,))
        con.execute("DELETE FROM reservas WHERE professor_id = ?", (prof_id,))
        con.execute("UPDATE observacoes SET professor_id = NULL WHERE professor_id = ?", (prof_id,))  # fica anonima
        con.execute("DELETE FROM professores WHERE id = ?", (prof_id,))
    return True, f"Professor {prof['nome']} excluido."


def excluir_tablet(tablet_id, forcar=False):
    """Retorna (ok, msg) ou (False, msg, True) quando precisa de confirmacao."""
    with conectar() as con:
        tablet = con.execute("SELECT * FROM tablets WHERE id = ?", (tablet_id,)).fetchone()
        if not tablet:
            return False, "Tablet nao encontrado."
        if tablet["status"] == "emprestado" or con.execute(
                "SELECT 1 FROM emprestimos WHERE tablet_id = ? AND devolucao IS NULL", (tablet_id,)).fetchone():
            return False, (f"O tablet {tablet['codigo']} esta emprestado. "
                           "Registre a devolucao antes de excluir.")

        n_emp = con.execute("SELECT COUNT(*) FROM emprestimos WHERE tablet_id = ?", (tablet_id,)).fetchone()[0]
        n_res = con.execute("SELECT COUNT(*) FROM reservas WHERE tablet_id = ?", (tablet_id,)).fetchone()[0]
        n_obs = con.execute("SELECT COUNT(*) FROM observacoes WHERE tablet_id = ?", (tablet_id,)).fetchone()[0]

        if (n_emp or n_res or n_obs) and not forcar:
            return False, (f"O tablet {tablet['codigo']} tem {_plural(n_emp, 'emprestimo', 'emprestimos')} no historico, "
                           f"{_plural(n_res, 'reserva', 'reservas')} e "
                           f"{_plural(n_obs, 'observacao', 'observacoes')}. Excluir o tablet tambem apaga esses registros."), True

        con.execute("DELETE FROM emprestimos WHERE tablet_id = ?", (tablet_id,))
        con.execute("DELETE FROM reservas WHERE tablet_id = ?", (tablet_id,))
        con.execute("DELETE FROM observacoes WHERE tablet_id = ?", (tablet_id,))
        con.execute("DELETE FROM tablets WHERE id = ?", (tablet_id,))
    return True, f"Tablet {tablet['codigo']} excluido."


# ------------------------------------------------------------------
# Reservas
# ------------------------------------------------------------------
def reservar(tag_professor, codigo_tablet, inicio, fim):
    agora_dt = datetime.now()
    if fim <= inicio:
        return False, "O horario final tem que ser depois do inicial."
    if inicio < agora_dt:
        return False, "Nao da pra reservar no passado."
    if inicio > agora_dt + timedelta(days=DIAS_MAX_ANTECEDENCIA):
        return False, f"Reserva muito antecipada (maximo {DIAS_MAX_ANTECEDENCIA} dias)."

    ini, fi = inicio.strftime(FMT_BANCO), fim.strftime(FMT_BANCO)
    with conectar() as con:
        prof = con.execute("SELECT * FROM professores WHERE tag_rfid = ?", (tag_professor,)).fetchone()
        tablet = con.execute("SELECT * FROM tablets WHERE codigo = ?", (codigo_tablet,)).fetchone()
        if not prof:
            return False, "Professor nao encontrado."
        if not tablet:
            return False, "Tablet nao encontrado."
        if tablet["status"] == "manutencao" or tablet["hardware"] != "ok":
            return False, "Esse tablet esta em manutencao (defeito registrado)."

        conflito = con.execute(
            """SELECT 1 FROM reservas
               WHERE tablet_id = ? AND status = 'ativa' AND inicio < ? AND fim > ?""",
            (tablet["id"], fi, ini)).fetchone()
        if conflito:
            return False, "Ja existe reserva desse tablet nesse horario."

        con.execute("INSERT INTO reservas (professor_id, tablet_id, inicio, fim) VALUES (?, ?, ?, ?)",
                    (prof["id"], tablet["id"], ini, fi))

    enviar_email(prof["email"], "Reserva confirmada - TabControl",
                 f"Ola {prof['nome']}, o tablet {codigo_tablet} foi reservado de "
                 f"{inicio.strftime(FMT_TELA)} ate {fim.strftime(FMT_TELA)}.")
    return True, "Reserva feita."


def cancelar_reserva(reserva_id, tag_professor):
    with conectar() as con:
        prof = con.execute("SELECT * FROM professores WHERE tag_rfid = ?", (tag_professor,)).fetchone()
        if not prof:
            return False, "Professor nao encontrado."
        res = con.execute("SELECT * FROM reservas WHERE id = ? AND status = 'ativa'",
                          (reserva_id,)).fetchone()
        if not res:
            return False, "Reserva ativa nao encontrada."
        if res["professor_id"] != prof["id"]:
            return False, "Essa reserva e de outro professor."
        con.execute("UPDATE reservas SET status = 'cancelada' WHERE id = ?", (reserva_id,))
    return True, "Reserva cancelada."


# ------------------------------------------------------------------
# Retirada e devolucao
# ------------------------------------------------------------------
def retirar(tag_professor, tag_tablet):
    agora_dt = datetime.now()
    limite = (agora_dt + timedelta(minutes=TOLERANCIA_RETIRADA_MIN)).strftime(FMT_BANCO)

    with conectar() as con:
        prof = con.execute("SELECT * FROM professores WHERE tag_rfid = ?", (tag_professor,)).fetchone()
        if not prof:
            return False, "Tag de professor nao cadastrada. Acesso negado."

        tablet = con.execute("SELECT * FROM tablets WHERE tag_rfid = ?", (tag_tablet,)).fetchone()
        if not tablet:
            return False, "Tag de tablet nao cadastrada."

        if tablet["status"] == "emprestado":
            return False, "Esse tablet ja esta emprestado."
        if tablet["status"] == "manutencao" or tablet["hardware"] != "ok":
            return False, "Tablet com problema de hardware / em manutencao."
        if tablet["bateria"] < BATERIA_MINIMA:
            return False, (f"Emprestimo bloqueado: bateria em {tablet['bateria']}% "
                           f"(minimo {BATERIA_MINIMA}%).")

        # tem reserva de outra pessoa valendo agora?
        reserva = con.execute(
            """SELECT * FROM reservas
               WHERE tablet_id = ? AND status = 'ativa' AND inicio <= ? AND fim >= ?""",
            (tablet["id"], limite, agora_dt.strftime(FMT_BANCO))).fetchone()
        if reserva and reserva["professor_id"] != prof["id"]:
            return False, "Tablet reservado por outro professor nesse horario."
        if reserva:
            con.execute("UPDATE reservas SET status = 'concluida' WHERE id = ?", (reserva["id"],))

        con.execute(
            """INSERT INTO emprestimos (professor_id, tablet_id, retirada, bateria_retirada)
               VALUES (?, ?, ?, ?)""",
            (prof["id"], tablet["id"], agora(), tablet["bateria"]))
        con.execute("UPDATE tablets SET status = 'emprestado' WHERE id = ?", (tablet["id"],))

    enviar_email(prof["email"], "Retirada de tablet - TabControl",
                 f"Ola {prof['nome']}, voce retirou o tablet {tablet['codigo']} "
                 f"em {agora_dt.strftime(FMT_TELA)} (bateria {tablet['bateria']}%).")
    return True, f"Liberado! {prof['nome']} retirou o {tablet['codigo']}. (fechadura aberta)"


def devolver(tag_tablet, bateria_atual, hardware="ok"):
    with conectar() as con:
        tablet = con.execute("SELECT * FROM tablets WHERE tag_rfid = ?", (tag_tablet,)).fetchone()
        if not tablet:
            return False, "Tag de tablet nao cadastrada."

        emp = con.execute(
            """SELECT e.*, p.nome, p.email FROM emprestimos e
               JOIN professores p ON p.id = e.professor_id
               WHERE e.tablet_id = ? AND e.devolucao IS NULL""", (tablet["id"],)).fetchone()
        if not emp:
            return False, "Nao tem emprestimo em aberto pra esse tablet."

        if tablet["hardware"] != "ok":
            hardware = "defeito"  # defeito registrado durante o emprestimo continua valendo
        novo_status = "disponivel" if hardware == "ok" else "manutencao"
        con.execute("UPDATE emprestimos SET devolucao = ?, bateria_devolucao = ? WHERE id = ?",
                    (agora(), bateria_atual, emp["id"]))
        con.execute("UPDATE tablets SET status = ?, bateria = ?, hardware = ? WHERE id = ?",
                    (novo_status, bateria_atual, hardware, tablet["id"]))

    enviar_email(emp["email"], "Devolucao registrada - TabControl",
                 f"Ola {emp['nome']}, a devolucao do tablet {tablet['codigo']} foi registrada.")

    if hardware != "ok" or bateria_atual < BATERIA_MINIMA:
        enviar_email(EMAIL_ADMIN, f"Atencao: tablet {tablet['codigo']}",
                     f"Devolvido com bateria {bateria_atual}% e hardware '{hardware}'. "
                     f"Ultimo usuario: {emp['nome']}.")
    return True, f"Devolucao do {tablet['codigo']} registrada."


# ------------------------------------------------------------------
# Observacoes / reclamacoes
# ------------------------------------------------------------------
def registrar_observacao(codigo_tablet, tag_professor, texto, defeito=False):
    """Se 'defeito' for True, o tablet fica bloqueado (retirada e reserva) e vai pra manutencao."""
    texto = texto.strip()
    if not texto:
        return False, "Descreva o que aconteceu."
    with conectar() as con:
        tablet = con.execute("SELECT * FROM tablets WHERE codigo = ?", (codigo_tablet,)).fetchone()
        if not tablet:
            return False, "Tablet nao encontrado."
        prof = con.execute("SELECT id FROM professores WHERE tag_rfid = ?", (tag_professor,)).fetchone()
        con.execute("""INSERT INTO observacoes (tablet_id, professor_id, data, texto, tipo)
                       VALUES (?, ?, ?, ?, ?)""",
                    (tablet["id"], prof["id"] if prof else None, agora(), texto,
                     "defeito" if defeito else "observacao"))
        if defeito:
            # emprestado continua emprestado; vai pra manutencao quando for devolvido
            novo_status = "manutencao" if tablet["status"] == "disponivel" else tablet["status"]
            con.execute("UPDATE tablets SET hardware = 'defeito', status = ? WHERE id = ?",
                        (novo_status, tablet["id"]))

    if not defeito:
        return True, "Observacao registrada."

    enviar_email(EMAIL_ADMIN, f"Defeito registrado: tablet {codigo_tablet}", texto)
    if tablet["status"] == "emprestado":
        return True, (f"Defeito registrado. O {codigo_tablet} esta emprestado e vai para "
                      "manutencao assim que for devolvido.")
    return True, f"Defeito registrado. O {codigo_tablet} foi bloqueado e enviado para manutencao."


# ------------------------------------------------------------------
# Consultas
# ------------------------------------------------------------------
def mostrar_tablets():
    with conectar() as con:
        linhas = con.execute("SELECT * FROM tablets ORDER BY codigo").fetchall()
    print(f"\n{'CODIGO':<10}{'TAG':<12}{'BATERIA':<10}{'HARDWARE':<10}STATUS")
    print("-" * 52)
    for t in linhas:
        alerta = "  <- bateria baixa" if t["bateria"] < BATERIA_MINIMA else ""
        print(f"{t['codigo']:<10}{t['tag_rfid']:<12}{str(t['bateria']) + '%':<10}"
              f"{t['hardware']:<10}{t['status']}{alerta}")


def mostrar_professores():
    with conectar() as con:
        linhas = con.execute("SELECT * FROM professores ORDER BY nome").fetchall()
    print(f"\n{'NOME':<25}{'EMAIL':<30}TAG")
    print("-" * 65)
    for p in linhas:
        print(f"{p['nome']:<25}{p['email']:<30}{p['tag_rfid']}")


def mostrar_reservas():
    with conectar() as con:
        linhas = con.execute(
            """SELECT r.id, p.nome, t.codigo, r.inicio, r.fim, r.status
               FROM reservas r
               JOIN professores p ON p.id = r.professor_id
               JOIN tablets t ON t.id = r.tablet_id
               ORDER BY r.inicio""").fetchall()
    print(f"\n{'ID':<5}{'PROFESSOR':<22}{'TABLET':<10}{'INICIO':<18}{'FIM':<18}STATUS")
    print("-" * 80)
    for r in linhas:
        print(f"{r['id']:<5}{r['nome']:<22}{r['codigo']:<10}"
              f"{para_tela(r['inicio']):<18}{para_tela(r['fim']):<18}{r['status']}")


def mostrar_historico():
    with conectar() as con:
        linhas = con.execute(
            """SELECT p.nome, t.codigo, e.retirada, e.devolucao,
                      e.bateria_retirada, e.bateria_devolucao
               FROM emprestimos e
               JOIN professores p ON p.id = e.professor_id
               JOIN tablets t ON t.id = e.tablet_id
               ORDER BY e.retirada DESC""").fetchall()
    print(f"\n{'PROFESSOR':<22}{'TABLET':<10}{'RETIRADA':<18}{'DEVOLUCAO':<18}BATERIA (ret > dev)")
    print("-" * 85)
    for h in linhas:
        dev_bat = f"{h['bateria_devolucao']}%" if h["bateria_devolucao"] is not None else "-"
        print(f"{h['nome']:<22}{h['codigo']:<10}{para_tela(h['retirada']):<18}"
              f"{para_tela(h['devolucao']):<18}{h['bateria_retirada']}% > {dev_bat}")


def mostrar_observacoes():
    with conectar() as con:
        linhas = con.execute(
            """SELECT o.data, t.codigo, COALESCE(p.nome, '-') AS nome, o.texto
               FROM observacoes o
               JOIN tablets t ON t.id = o.tablet_id
               LEFT JOIN professores p ON p.id = o.professor_id
               ORDER BY o.data DESC""").fetchall()
    print()
    for o in linhas:
        print(f"[{para_tela(o['data'])}] {o['codigo']} ({o['nome']}): {o['texto']}")
    if not linhas:
        print("Nenhuma observacao registrada.")


# ------------------------------------------------------------------
# Dados de exemplo (pra testar rapido)
# ------------------------------------------------------------------
def carregar_exemplo():
    cadastrar_professor("Ana Souza", "ana@exemplo.com", "P001")
    cadastrar_professor("Carlos Lima", "carlos@exemplo.com", "P002")
    for i, bat in enumerate([95, 60, 15], start=1):
        cadastrar_tablet(f"TAB-{i:02d}", f"T00{i}")
        atualizar_status_tablet(f"TAB-{i:02d}", bat, "ok")
    print("Exemplo carregado: professores P001 e P002 | tablets T001, T002 e T003 (T003 com 15%).")


# ------------------------------------------------------------------
# Menu
# ------------------------------------------------------------------
def resposta(resultado):
    ok, msg = resultado
    print(("\n[OK] " if ok else "\n[ERRO] ") + msg)


def pedir_inteiro(msg):
    try:
        return int(input(msg).strip())
    except ValueError:
        return None


def menu():
    opcoes = """
===== TabControl =====
 1  - Retirar tablet (RFID)
 2  - Devolver tablet
 3  - Reservar horario
 4  - Cancelar reserva
 5  - Listar tablets
 6  - Listar reservas
 7  - Historico de retiradas/devolucoes
 8  - Cadastrar professor
 9  - Cadastrar tablet
10  - Atualizar bateria/hardware (simula ESP32)
11  - Registrar observacao/reclamacao
12  - Ver observacoes
13  - Listar professores
14  - Carregar dados de exemplo
 0  - Sair
"""
    while True:
        print(opcoes)
        op = input("Escolha: ").strip()

        if op == "1":
            tag_p = ler_tag("Aproxime a tag do professor: ")
            tag_t = ler_tag("Aproxime a tag do tablet: ")
            resposta(retirar(tag_p, tag_t))

        elif op == "2":
            tag_t = ler_tag("Aproxime a tag do tablet: ")
            bat = pedir_inteiro("Bateria atual (%): ")
            if bat is None:
                print("\n[ERRO] Bateria invalida.")
                continue
            hw = input("Hardware ok? (s/n): ").strip().lower()
            resposta(devolver(tag_t, bat, "ok" if hw != "n" else "defeito"))

        elif op == "3":
            tag_p = ler_tag("Tag do professor: ")
            codigo = input("Codigo do tablet: ").strip()
            ini = ler_data(input("Inicio (dd/mm/aaaa hh:mm): "))
            fim = ler_data(input("Fim    (dd/mm/aaaa hh:mm): "))
            if not ini or not fim:
                print("\n[ERRO] Data/hora invalida. Use o formato dd/mm/aaaa hh:mm")
                continue
            resposta(reservar(tag_p, codigo, ini, fim))

        elif op == "4":
            rid = pedir_inteiro("ID da reserva: ")
            tag_p = ler_tag("Tag do professor: ")
            if rid is None:
                print("\n[ERRO] ID invalido.")
                continue
            resposta(cancelar_reserva(rid, tag_p))

        elif op == "5":
            mostrar_tablets()
        elif op == "6":
            mostrar_reservas()
        elif op == "7":
            mostrar_historico()

        elif op == "8":
            nome = input("Nome: ").strip()
            email = input("Email: ").strip()
            tag = ler_tag("Tag RFID: ")
            resposta(cadastrar_professor(nome, email, tag))

        elif op == "9":
            codigo = input("Codigo do tablet (ex: TAB-04): ").strip()
            tag = ler_tag("Tag RFID: ")
            resposta(cadastrar_tablet(codigo, tag))

        elif op == "10":
            codigo = input("Codigo do tablet: ").strip()
            bat = pedir_inteiro("Bateria (%): ")
            hw = input("Hardware (ok/defeito): ").strip().lower()
            if bat is None:
                print("\n[ERRO] Bateria invalida.")
                continue
            resposta(atualizar_status_tablet(codigo, bat, hw))

        elif op == "11":
            codigo = input("Codigo do tablet: ").strip()
            tag_p = ler_tag("Tag do professor (Enter pra deixar anonimo): ")
            texto = input("Observacao: ").strip()
            defeito = input("E um defeito que impede o uso? (s/n): ").strip().lower() == "s"
            resposta(registrar_observacao(codigo, tag_p, texto, defeito))

        elif op == "12":
            mostrar_observacoes()
        elif op == "13":
            mostrar_professores()
        elif op == "14":
            carregar_exemplo()
        elif op == "0":
            print("Ate mais!")
            break
        else:
            print("\nOpcao invalida.")


if __name__ == "__main__":
    criar_tabelas()
    menu()